package Pantallas;
import javax.swing.*;

	public class Productos extends JFrame {
		public Productos() {
			setTitle ("Productos");
			setSize (500,700);
			setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			setLocationRelativeTo (null);
			JLabel label = new JLabel("Lista de productos:");
	       

	       
	        add(label);
	    }
	}





